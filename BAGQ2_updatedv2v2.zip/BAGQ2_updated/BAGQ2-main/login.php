<!DOCTYPE html>
<html lang="eng">
<head>
    <title>BAG-Q</title>
</head>
<body>

    <h1>Login Form</h1>
    <br><br><br><br>
    <div style="background-color: grey; width: 500px">
        <label>username</label>
        <input type="text" name="username" required>
    </div>

    <div>
        <label>password</label>
        <input type="password" name="password" required>
    </div>

    <div>
        <input type="submit" value="login">
    </div>


</body>
</html>